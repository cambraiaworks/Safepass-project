document.addEventListener('DOMContentLoaded', () => {

  /* ============ Header scroll effect ============ */
  const header = document.getElementById('site-header');
  window.addEventListener('scroll', () => {
    if (window.scrollY > 20) header.classList.add('scrolled');
    else header.classList.remove('scrolled');
  });

  /* ============ Login state ============ */
  let isLoggedIn = false;
  const btnLogin = document.getElementById('btn-login');
  const btnLogout = document.getElementById('btn-logout');
  const btnRegisterNav = document.getElementById('btn-register');

  function refreshAuthUI() {
    btnLogin.classList.toggle('hidden', isLoggedIn);
    btnLogout.classList.toggle('hidden', !isLoggedIn);
    btnRegisterNav.classList.toggle('hidden', isLoggedIn);
  }

  btnLogout.addEventListener('click', () => {
    isLoggedIn = false;
    refreshAuthUI();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  /* ============ Modal system ============ */
  const overlay = document.getElementById('modal-overlay');
  const modals = {
    login: document.getElementById('modal-login'),
    register: document.getElementById('modal-register'),
    feedback: document.getElementById('modal-feedback'),
    referral: document.getElementById('modal-referral'),
  };

  function openModal(name) {
    Object.values(modals).forEach(m => m.classList.add('hidden'));
    modals[name].classList.remove('hidden');
    overlay.classList.remove('hidden');
  }

  function closeModal() {
    overlay.classList.add('hidden');
    Object.values(modals).forEach(m => m.classList.add('hidden'));
  }

  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeModal();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !overlay.classList.contains('hidden')) closeModal();
  });

  document.querySelectorAll('.modal-close').forEach(btn => {
    btn.addEventListener('click', closeModal);
  });

  document.getElementById('btn-login').addEventListener('click', () => openModal('login'));
  document.querySelectorAll('.open-register').forEach(btn => {
    btn.addEventListener('click', () => openModal('register'));
  });
  document.getElementById('btn-referral').addEventListener('click', () => openModal('referral'));
  document.getElementById('btn-feedback').addEventListener('click', () => openModal('feedback'));

  document.querySelectorAll('.open-register-from-login').forEach(btn => {
    btn.addEventListener('click', () => openModal('register'));
  });
  document.querySelectorAll('.open-login-from-register').forEach(btn => {
    btn.addEventListener('click', () => openModal('login'));
  });

  /* ============ Login modal logic ============ */
  const loginStepForm = document.getElementById('login-step-form');
  const loginStepForgot = document.getElementById('login-step-forgot');
  const btnForgot = document.getElementById('btn-forgot');
  const btnBackToLogin = document.getElementById('btn-back-to-login');
  const formLogin = document.getElementById('form-login');
  const formForgot = document.getElementById('form-forgot');
  const forgotSent = document.getElementById('forgot-sent');
  const forgotEmailInput = document.getElementById('forgot-email');
  const forgotEmailDisplay = document.getElementById('forgot-email-display');

  function resetLoginModal() {
    loginStepForm.classList.remove('hidden');
    loginStepForgot.classList.add('hidden');
    formForgot.classList.remove('hidden');
    forgotSent.classList.add('hidden');
    formLogin.reset();
    formForgot.reset();
  }

  btnForgot.addEventListener('click', () => {
    loginStepForm.classList.add('hidden');
    loginStepForgot.classList.remove('hidden');
  });

  btnBackToLogin.addEventListener('click', () => {
    resetLoginModal();
  });

  formLogin.addEventListener('submit', (e) => {
    e.preventDefault();
    isLoggedIn = true;
    refreshAuthUI();
    closeModal();
    resetLoginModal();
  });

  formForgot.addEventListener('submit', (e) => {
    e.preventDefault();
    forgotEmailDisplay.textContent = forgotEmailInput.value;
    formForgot.classList.add('hidden');
    forgotSent.classList.remove('hidden');
  });

  /* Reset login modal state whenever it's reopened via header button */
  document.getElementById('btn-login').addEventListener('click', resetLoginModal);

  /* ============ Register modal logic ============ */
  const registerStepType = document.getElementById('register-step-type');
  const registerStepForm = document.getElementById('register-step-form');
  const registerTypeLabel = document.getElementById('register-type-label');
  const btnRegisterBack = document.getElementById('btn-register-back');
  const formRegister = document.getElementById('form-register');

  function resetRegisterModal() {
    registerStepType.classList.remove('hidden');
    registerStepForm.classList.add('hidden');
    formRegister.reset();
  }

  document.querySelectorAll('.type-option').forEach(opt => {
    opt.addEventListener('click', () => {
      registerTypeLabel.textContent = opt.dataset.label;
      registerStepType.classList.add('hidden');
      registerStepForm.classList.remove('hidden');
    });
  });

  btnRegisterBack.addEventListener('click', () => {
    registerStepType.classList.remove('hidden');
    registerStepForm.classList.add('hidden');
  });

  formRegister.addEventListener('submit', (e) => {
    e.preventDefault();
    closeModal();
    resetRegisterModal();
  });

  document.querySelectorAll('.open-register').forEach(btn => {
    btn.addEventListener('click', resetRegisterModal);
  });
  document.querySelectorAll('.open-register-from-login').forEach(btn => {
    btn.addEventListener('click', resetRegisterModal);
  });

  /* ============ Feedback modal logic ============ */
  const formFeedback = document.getElementById('form-feedback');
  const feedbackSuccess = document.getElementById('feedback-success');

  document.getElementById('btn-feedback').addEventListener('click', () => {
    formFeedback.classList.remove('hidden');
    feedbackSuccess.classList.add('hidden');
    formFeedback.reset();
    resetStarRating(feedbackStarRating);
  });

  formFeedback.addEventListener('submit', (e) => {
    e.preventDefault();
    formFeedback.classList.add('hidden');
    feedbackSuccess.classList.remove('hidden');
  });

  /* ============ Referral modal logic ============ */
  const formReferral = document.getElementById('form-referral');
  const referralSuccess = document.getElementById('referral-success');

  document.getElementById('btn-referral').addEventListener('click', () => {
    formReferral.classList.remove('hidden');
    referralSuccess.classList.add('hidden');
    formReferral.reset();
  });

  formReferral.addEventListener('submit', (e) => {
    e.preventDefault();
    formReferral.classList.add('hidden');
    referralSuccess.classList.remove('hidden');
  });

  /* ============ Star rating widget (feedback form) ============ */
  function buildStarRating(container) {
    container.innerHTML = '';
    let value = 0;
    for (let i = 1; i <= 5; i++) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
      btn.addEventListener('mouseenter', () => paintStars(container, i));
      btn.addEventListener('mouseleave', () => paintStars(container, value));
      btn.addEventListener('click', () => {
        value = i;
        container.dataset.rating = String(value);
        paintStars(container, value);
      });
      container.appendChild(btn);
    }
  }

  function paintStars(container, count) {
    const buttons = container.querySelectorAll('button');
    buttons.forEach((b, idx) => {
      const filled = idx < count;
      b.classList.toggle('filled', filled);
      const svg = b.querySelector('svg');
      svg.setAttribute('fill', filled ? 'currentColor' : 'none');
    });
  }

  function resetStarRating(container) {
    container.dataset.rating = '0';
    paintStars(container, 0);
  }

  const feedbackStarRating = document.querySelector('.star-rating[data-target="feedback"]');
  buildStarRating(feedbackStarRating);

  /* ============ Testimonials carousel ============ */
  const testimonials = [
    { name: "Ana Lima", role: "Usuária", rating: 5, text: "Incrível! Economizei mais de R$300 em consultas só no primeiro mês. O SAFEpass transformou o cuidado com minha família." },
    { name: "Dr. Marcos Ferreira", role: "Prestador", rating: 5, text: "Minha clínica ganhou visibilidade enorme. Os agendamentos aumentaram 40% desde que entrei na plataforma." },
    { name: "TechCorp Brasília", role: "Empresa", rating: 5, text: "Oferecemos o SAFEpass como benefício e a satisfação dos colaboradores aumentou muito. Recomendo demais!" },
    { name: "Juliana Souza", role: "Usuária", rating: 4, text: "Facilidade incrível para encontrar médicos perto de mim com valores acessíveis. O app é muito intuitivo." },
    { name: "Clínica Saúde Total", role: "Prestador", rating: 5, text: "Gerenciar atestados e convênios ficou muito mais simples. A plataforma é excelente para nosso negócio." },
    { name: "Ricardo Alves", role: "Usuário", rating: 5, text: "Já resgatei R$150 em benefícios só avaliando os atendimentos. O sistema de pontos é fantástico!" },
    { name: "Grupo Inovação RH", role: "Empresa", rating: 4, text: "Solução perfeita para benefícios corporativos. Nossa equipe adorou e a implementação foi muito rápida." },
    { name: "Dra. Carla Nunes", role: "Prestador", rating: 5, text: "Os cupons exclusivos da plataforma trouxeram muitos pacientes novos. Estou muito satisfeita com os resultados." },
    { name: "Paulo Henrique", role: "Usuário", rating: 5, text: "O SAFEpass cuida da saúde de toda minha família por um preço que eu consigo pagar. Muito bom mesmo!" },
  ];

  const perPage = 3;
  const totalPages = Math.ceil(testimonials.length / perPage);
  let page = 0;

  const grid = document.getElementById('testimonials-grid');
  const dotsWrap = document.getElementById('test-dots');
  const prevBtn = document.getElementById('test-prev');
  const nextBtn = document.getElementById('test-next');

  function renderTestimonials() {
    grid.innerHTML = '';
    const visible = testimonials.slice(page * perPage, page * perPage + perPage);
    visible.forEach(t => {
      const card = document.createElement('div');
      card.className = 'testimonial-card';

      const stars = document.createElement('div');
      stars.className = 'star-rating small';
      for (let i = 1; i <= 5; i++) {
        const s = document.createElement('span');
        s.style.width = '1.25rem';
        s.style.height = '1.25rem';
        s.style.color = i <= t.rating ? '#F5A623' : '#CBD5E0';
        s.innerHTML = `<svg viewBox="0 0 24 24" fill="${i <= t.rating ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="1.5" style="width:100%;height:100%"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`;
        stars.appendChild(s);
      }

      const text = document.createElement('p');
      text.className = 'testimonial-text';
      text.textContent = `"${t.text}"`;

      const nameWrap = document.createElement('div');
      const name = document.createElement('div');
      name.className = 'testimonial-name';
      name.textContent = t.name;
      const role = document.createElement('div');
      role.className = 'testimonial-role';
      role.textContent = t.role;
      nameWrap.appendChild(name);
      nameWrap.appendChild(role);

      card.appendChild(stars);
      card.appendChild(text);
      card.appendChild(nameWrap);
      grid.appendChild(card);
    });

    dotsWrap.innerHTML = '';
    for (let i = 0; i < totalPages; i++) {
      const dot = document.createElement('button');
      dot.className = 'carousel-dot' + (i === page ? ' active' : '');
      dot.addEventListener('click', () => { page = i; renderTestimonials(); });
      dotsWrap.appendChild(dot);
    }

    prevBtn.disabled = page === 0;
    nextBtn.disabled = page === totalPages - 1;
  }

  prevBtn.addEventListener('click', () => { if (page > 0) { page--; renderTestimonials(); } });
  nextBtn.addEventListener('click', () => { if (page < totalPages - 1) { page++; renderTestimonials(); } });

  renderTestimonials();

});
